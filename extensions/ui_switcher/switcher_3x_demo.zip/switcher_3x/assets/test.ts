
import { _decorator, Component, Node } from 'cc';
import { UISwitcher } from './ui_switcher';
const { ccclass, property } = _decorator;



@ccclass('test')
export class test extends Component {

    @property(UISwitcher)
    switcher: UISwitcher | null = null

    @property(Node)
    btn1: Node | null = null

    @property(Node)
    btn2: Node | null = null

    start() {
        this.btn1?.on("click", this.onBtn1Click, this)
        this.btn2?.on("click", this.onBtn2Click, this)
    }

    onBtn1Click() {
        this.switcher?.changeStateByIndex(0)
        //this.switcher?.changeStateByName("1")
    }

    onBtn2Click() {
        // this.switcher?.changeStateByIndex(1)
        this.switcher?.changeStateByName("2")
    }

}

