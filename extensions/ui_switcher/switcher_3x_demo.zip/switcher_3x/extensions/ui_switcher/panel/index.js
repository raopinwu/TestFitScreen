// panel/index.js, this filename needs to match the one registered in package.json
Editor.Panel.extend({
  // css style for panel
  style: `
  `,

  // html template for panel
  template: `
  `,

  // element and variable binding
  $: {
  },

  // method executed when template and styles are successfully loaded and initialized
  ready () {
  },

  // register your ipc messages here
  messages: {
  }
});